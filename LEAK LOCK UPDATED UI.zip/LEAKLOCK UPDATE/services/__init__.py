"""
LEAKLOCK — Phase 4 Hardened Gateway Orchestration, Redaction, & Audit Bridge.
Provides fail-closed pipeline execution, overlap-safe span redaction,
input-size enforcement, Luhn validation, SHA-256 prompt fingerprinting,
and thread-safe metadata-only audit logging.
"""

from __future__ import annotations

from collections import deque
import dataclasses
from datetime import datetime, timezone
import hashlib
import inspect
import json
from pathlib import Path
import re
import threading
from typing import Any, Dict, List, Optional, Sequence, Tuple

from config import settings
from core import audit_logger, detector, policy_engine, risk_scorer, threat_detector

__version__ = "0.4.0"

REQUIRED_ROLES: Tuple[str, ...] = (
    "PUBLIC_ASSISTANT",
    "INTERNAL_ANALYST",
    "PRIVILEGED_DEBUGGER",
    "AUTOMATED_PIPELINE",
)

DEFAULT_MAX_PROMPT_LENGTH: int = int(
    getattr(settings, "MAX_PROMPT_LENGTH", getattr(settings, "MAX_INPUT_LENGTH", 10_000))
)

FORBIDDEN_AUDIT_KEYS = frozenset({
    "prompt",
    "raw_prompt",
    "original_prompt",
    "sanitized_prompt",
    "redacted_prompt",
    "secret",
    "matched_value",
    "raw_value",
    "value",
    "match_text",
    "raw_match",
    "matched_text",
})

_AUDIT_LOCK = threading.RLock()
_FALLBACK_AUDIT_EVENTS: List[Dict[str, Any]] = []


def to_dict(obj: Any) -> Dict[str, Any]:
    """Normalize dataclass, Pydantic model, object, or dict into a plain dict."""
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return dict(obj)
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return dataclasses.asdict(obj)
    if hasattr(obj, "model_dump") and callable(obj.model_dump):
        return obj.model_dump()
    if hasattr(obj, "to_dict") and callable(obj.to_dict):
        return obj.to_dict()
    if hasattr(obj, "__dict__"):
        return {k: v for k, v in vars(obj).items() if not k.startswith("_")}
    return {"value": obj}


def compute_prompt_fingerprint(prompt: str) -> str:
    """Compute a deterministic, privacy-preserving SHA-256 fingerprint of a prompt."""
    if not isinstance(prompt, str):
        return "sha256:invalid"
    digest = hashlib.sha256(prompt.encode("utf-8", errors="replace")).hexdigest()
    return f"sha256:{digest[:16]}"


def is_luhn_valid(number_str: str) -> bool:
    """Validate credit-card-like numeric strings using the Luhn checksum algorithm."""
    digits = [int(ch) for ch in re.sub(r"[\s\-]", "", str(number_str)) if ch.isdigit()]
    if len(digits) < 13 or len(digits) > 19:
        return False
    # Reject all-zero strings
    if sum(digits) == 0:
        return False
    checksum = 0
    reverse_digits = digits[::-1]
    for idx, d in enumerate(reverse_digits):
        if idx % 2 == 1:
            doubled = d * 2
            checksum += doubled - 9 if doubled > 9 else doubled
        else:
            checksum += d
    return checksum % 10 == 0


def redact_spans_safely(
    text: str,
    spans: Sequence[Dict[str, Any]],
    marker_template: str = "[REDACTED:{category}]",
) -> str:
    """
    Deterministic, overlap-safe span redaction.
    1. Filters out invalid or inverted spans (start < 0, end > len(text), start >= end).
    2. Sorts spans by (start ASC, end DESC).
    3. Merges overlapping spans while preserving all unique category names in order.
    4. Replaces spans from right to left so character offsets never drift.
    """
    if not isinstance(text, str) or not text or not spans:
        return text if isinstance(text, str) else ""

    text_len = len(text)
    valid_intervals: List[Tuple[int, int, List[str]]] = []

    for item in spans:
        d = to_dict(item)
        start = d.get("start")
        end = d.get("end")
        if start is None or end is None:
            span_tuple = d.get("span")
            if isinstance(span_tuple, (tuple, list)) and len(span_tuple) == 2:
                start, end = span_tuple[0], span_tuple[1]
        if not isinstance(start, int) or not isinstance(end, int):
            continue
        start = max(0, start)
        end = min(text_len, end)
        if start >= end:
            continue

        raw_cat = (
            d.get("category")
            or d.get("type")
            or d.get("entity_type")
            or d.get("label")
            or "SENSITIVE_DATA"
        )
        cat_str = str(raw_cat.value if hasattr(raw_cat, "value") else raw_cat).upper()
        valid_intervals.append((start, end, [cat_str]))

    if not valid_intervals:
        return text

    # Sort by start ascending, then by end descending
    valid_intervals.sort(key=lambda x: (x[0], -x[1]))

    merged: List[Tuple[int, int, List[str]]] = []
    for start, end, cats in valid_intervals:
        if not merged:
            merged.append((start, end, list(cats)))
        else:
            prev_start, prev_end, prev_cats = merged[-1]
            if start < prev_end:  # Strictly overlapping span
                new_end = max(prev_end, end)
                for c in cats:
                    if c not in prev_cats:
                        prev_cats.append(c)
                merged[-1] = (prev_start, new_end, prev_cats)
            else:
                merged.append((start, end, list(cats)))

    # Replace right-to-left to preserve character offsets
    result = text
    for start, end, cats in reversed(merged):
        combined_cat = "+".join(cats)
        replacement = marker_template.format(category=combined_cat)
        result = result[:start] + replacement + result[end:]

    return result


def get_max_prompt_length() -> int:
    """Return the active maximum prompt length in characters."""
    val = getattr(settings, "MAX_PROMPT_LENGTH", getattr(settings, "MAX_INPUT_LENGTH", DEFAULT_MAX_PROMPT_LENGTH))
    if isinstance(val, int) and val > 0:
        return val
    return DEFAULT_MAX_PROMPT_LENGTH


def get_available_roles() -> List[str]:
    """Return configured agent roles from settings or policy_engine."""
    for module in (policy_engine, settings):
        for attr in ("AGENT_ROLES", "ROLES", "ROLE_POLICIES", "POLICIES", "DEFAULT_POLICIES", "AgentRole"):
            val = getattr(module, attr, None)
            if val is None:
                continue
            if isinstance(val, dict) and val:
                return [str(k.value if hasattr(k, "value") else k) for k in val.keys()]
            if isinstance(val, (list, tuple, set)) and val:
                return [str(x.value if hasattr(x, "value") else x) for x in val]
            if inspect.isclass(val) and hasattr(val, "__members__"):
                return list(val.__members__.keys())
    return list(REQUIRED_ROLES)


def get_supported_categories() -> List[str]:
    """Extract supported sensitive-data categories from the real detector or settings."""
    for module in (detector, settings, policy_engine):
        for attr in (
            "DEFAULT_CATEGORY_RISK_MAP",
            "CATEGORY_RISK_MAP",
            "PATTERNS",
            "SENSITIVE_PATTERNS",
            "DETECTION_PATTERNS",
            "CATEGORIES",
            "SENSITIVE_CATEGORIES",
            "SUPPORTED_CATEGORIES",
        ):
            val = getattr(module, attr, None)
            if isinstance(val, dict) and val:
                return sorted(str(k) for k in val.keys())
            if isinstance(val, (list, tuple, set)) and val:
                return sorted(str(k) for k in val)

    for cls_name in ("SensitiveDataDetector", "Detector", "PromptDetector"):
        cls = getattr(detector, cls_name, None)
        if inspect.isclass(cls):
            try:
                inst = cls()
                for attr in ("patterns", "categories", "rules"):
                    val = getattr(inst, attr, None)
                    if isinstance(val, dict) and val:
                        return sorted(str(k) for k in val.keys())
            except Exception:
                pass
    return []


def load_sample_prompts() -> List[Dict[str, Any]]:
    """Load synthetic sample prompts from data/sample_prompts.json."""
    repo_root = Path(__file__).resolve().parent.parent
    sample_path = repo_root / "data" / "sample_prompts.json"
    if not sample_path.exists():
        return []
    try:
        raw = json.loads(sample_path.read_text(encoding="utf-8"))
        if isinstance(raw, list):
            return [
                {**item, "prompt": item.get("prompt") or item.get("prompt_text") or item.get("text", "")}
                for item in raw
                if isinstance(item, dict) and ("prompt" in item or "prompt_text" in item or "text" in item)
            ]
        if isinstance(raw, dict):
            for key in ("samples", "prompts", "items", "data"):
                if isinstance(raw.get(key), list):
                    return [
                        {**item, "prompt": item.get("prompt") or item.get("prompt_text") or item.get("text", "")}
                        for item in raw[key]
                        if isinstance(item, dict) and ("prompt" in item or "prompt_text" in item or "text" in item)
                    ]
    except Exception:
        return []
    return []


def run_detection(prompt: str) -> Any:
    """Invoke the real sensitive-data detector in core/detector.py."""
    for fn_name in (
        "detect_sensitive_data",
        "detect",
        "scan_prompt",
        "analyze_prompt",
        "find_sensitive_data",
    ):
        fn = getattr(detector, fn_name, None)
        if callable(fn):
            return fn(prompt)

    for cls_name in ("SensitiveDataDetector", "Detector", "DataDetector"):
        cls = getattr(detector, cls_name, None)
        if inspect.isclass(cls):
            instance = cls()
            for method_name in ("detect", "scan", "analyze", "detect_sensitive_data"):
                method = getattr(instance, method_name, None)
                if callable(method):
                    return method(prompt)

    raise RuntimeError("No compatible detection entrypoint found in core.detector.")


def run_threat_detection(prompt: str) -> Any:
    """Invoke the real threat detector in core/threat_detector.py."""
    for fn_name in (
        "detect_prompt_threats",
        "detect_threats",
        "analyze_threats",
        "scan_threats",
        "detect",
        "evaluate_threats",
    ):
        fn = getattr(threat_detector, fn_name, None)
        if callable(fn):
            return fn(prompt)

    for cls_name in ("ThreatDetector", "PromptThreatDetector"):
        cls = getattr(threat_detector, cls_name, None)
        if inspect.isclass(cls):
            instance = cls()
            for method_name in ("detect_prompt_threats", "detect_threats", "detect", "scan", "analyze"):
                method = getattr(instance, method_name, None)
                if callable(method):
                    return method(prompt)

    raise RuntimeError("No compatible threat detection entrypoint found in core.threat_detector.")


def _call_with_matched_args(
    callable_obj: Any,
    available: Dict[str, Any],
    positional_fallback: Tuple[Any, ...],
) -> Any:
    """Bind parameters by signature inspection before falling back to positional arguments."""
    try:
        sig = inspect.signature(callable_obj)
        params = list(sig.parameters.values())
        kwargs: Dict[str, Any] = {}
        accepts_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params)
        required_params = [
            p
            for p in params
            if p.default is inspect.Parameter.empty
            and p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
        ]
        for p in params:
            if p.name in available:
                kwargs[p.name] = available[p.name]
        if kwargs and (all(rp.name in kwargs for rp in required_params) or accepts_var_kw):
            return callable_obj(**kwargs)
    except Exception:
        pass
    return callable_obj(*positional_fallback)


def run_risk_scoring(
    detection_result: Any,
    threat_result: Any,
    role: str = "PUBLIC_ASSISTANT",
    prompt: str = "",
) -> Any:
    """Invoke the real risk scorer in core/risk_scorer.py."""
    findings = []
    if isinstance(detection_result, dict):
        findings = detection_result.get("findings", [])
    elif isinstance(detection_result, list):
        findings = detection_result

    context = {
        "text": prompt or "",
        "prompt": prompt or "",
        "findings": findings,
        "threat_report": threat_result,
        "detections": detection_result,
        "detection_result": detection_result,
        "sensitive_findings": detection_result,
        "threats": threat_result,
        "threat_result": threat_result,
        "threat_findings": threat_result,
        "role": role,
        "agent_role": role,
    }
    for fn_name in (
        "calculate_contextual_risk",
        "calculate_risk_score",
        "score_risk",
        "evaluate_risk",
        "calculate_risk",
        "compute_risk",
    ):
        fn = getattr(risk_scorer, fn_name, None)
        if callable(fn):
            for fallback in (
                (prompt or "", findings, threat_result),
                (detection_result, threat_result),
                (detection_result,),
            ):
                try:
                    return _call_with_matched_args(fn, context, fallback)
                except TypeError:
                    continue

    for cls_name in ("RiskScorer", "PromptRiskScorer"):
        cls = getattr(risk_scorer, cls_name, None)
        if inspect.isclass(cls):
            instance = cls()
            for method_name in ("calculate_contextual_risk", "calculate_risk_score", "score", "calculate", "evaluate"):
                method = getattr(instance, method_name, None)
                if callable(method):
                    for fallback in (
                        (prompt or "", findings, threat_result),
                        (detection_result, threat_result),
                        (detection_result,),
                    ):
                        try:
                            return _call_with_matched_args(method, context, fallback)
                        except TypeError:
                            continue

    raise RuntimeError("No compatible risk scoring entrypoint found in core.risk_scorer.")


def run_policy_evaluation(
    prompt: str,
    role: str,
    detection_result: Any,
    threat_result: Any,
    risk_result: Any,
) -> Any:
    """Invoke the real policy engine in core/policy_engine.py."""
    context = {
        "prompt": prompt,
        "text": prompt,
        "prompt_text": prompt,
        "original_prompt": prompt,
        "role": role,
        "agent_role": role,
        "scan_result": detection_result,
        "detections": detection_result,
        "detection_result": detection_result,
        "sensitive_findings": detection_result,
        "findings": detection_result,
        "threats": threat_result,
        "threat_result": threat_result,
        "threat_findings": threat_result,
        "risk": risk_result,
        "risk_result": risk_result,
        "risk_assessment": risk_result,
        "risk_score": _extract_risk_score(risk_result),
    }

    for fn_name in (
        "evaluate_policy",
        "apply_policy",
        "evaluate",
        "enforce_policy",
        "process_prompt",
    ):
        fn = getattr(policy_engine, fn_name, None)
        if callable(fn):
            for fallback in (
                (prompt, detection_result, role),
                (prompt, role, detection_result, threat_result, risk_result),
                (role, detection_result, threat_result, risk_result),
                (prompt, detection_result, threat_result, risk_result, role),
                (prompt, role, detection_result, threat_result),
                (prompt, role, detection_result),
            ):
                try:
                    return _call_with_matched_args(fn, context, fallback)
                except (TypeError, AttributeError):
                    continue

    for cls_name in ("PolicyEngine", "SecurityPolicyEngine", "GatewayPolicyEngine"):
        cls = getattr(policy_engine, cls_name, None)
        if inspect.isclass(cls):
            instance = cls()
            for method_name in ("evaluate_policy", "evaluate", "apply_policy", "enforce", "process_prompt"):
                method = getattr(instance, method_name, None)
                if callable(method):
                    for fallback in (
                        (prompt, detection_result, role),
                        (prompt, role, detection_result, threat_result, risk_result),
                        (role, detection_result, threat_result, risk_result),
                        (prompt, detection_result, threat_result, risk_result, role),
                        (prompt, role, detection_result, threat_result),
                        (prompt, role, detection_result),
                    ):
                        try:
                            return _call_with_matched_args(method, context, fallback)
                        except (TypeError, AttributeError):
                            continue

    raise RuntimeError("No compatible policy evaluation entrypoint found in core.policy_engine.")


def _extract_risk_score(risk_result: Any) -> int:
    """Extract and clamp risk score strictly within [0, 100]."""
    if isinstance(risk_result, bool):
        raise ValueError("Boolean is not a valid risk score.")
    if isinstance(risk_result, (int, float)):
        return max(0, min(100, int(round(risk_result))))
    d = to_dict(risk_result)
    for key in ("risk_score", "score", "total_score", "value"):
        val = d.get(key)
        if isinstance(val, (int, float)) and not isinstance(val, bool):
            return max(0, min(100, int(round(val))))
    return 0


def _extract_severity(risk_result: Any, score: int) -> str:
    d = to_dict(risk_result)
    for key in ("severity", "risk_level", "level", "rating"):
        val = d.get(key)
        if val:
            return str(val.value if hasattr(val, "value") else val).upper()
    if score >= 80:
        return "CRITICAL"
    if score >= 60:
        return "HIGH"
    if score >= 30:
        return "MEDIUM"
    if score > 0:
        return "LOW"
    return "NONE"


def _normalize_findings(
    detection_result: Any,
) -> Tuple[List[str], List[Dict[str, Any]], List[Dict[str, Any]], List[str]]:
    """
    Return:
      - categories: unique category names
      - findings_meta: sanitized metadata for UI display (never includes raw secrets)
      - raw_spans: span dicts with start/end/category for overlap-safe redaction
      - matched_secrets: raw matched substrings (used ONLY internally to verify redaction completeness)
    """
    categories: List[str] = []
    findings_meta: List[Dict[str, Any]] = []
    raw_spans: List[Dict[str, Any]] = []
    matched_secrets: List[str] = []

    if detection_result is None:
        raise ValueError("Detection result cannot be None.")

    raw_items: List[Any] = []
    if isinstance(detection_result, list):
        raw_items = detection_result
    else:
        d = to_dict(detection_result)
        for key in ("findings", "matches", "detections", "entities", "items"):
            if isinstance(d.get(key), list):
                raw_items = d[key]
                break
        if isinstance(d.get("categories"), (list, set, tuple)):
            for c in d["categories"]:
                c_str = str(c.value if hasattr(c, "value") else c)
                if c_str not in categories:
                    categories.append(c_str)
        elif isinstance(d, dict) and not raw_items and not categories:
            for k, v in d.items():
                if k not in (
                    "has_sensitive_data",
                    "count",
                    "total",
                    "redacted_text",
                    "sanitized_prompt",
                    "value",
                ) and v:
                    if isinstance(v, list):
                        categories.append(str(k))
                        findings_meta.append({"category": str(k), "count": len(v)})
                        for sub in v:
                            if isinstance(sub, str) and sub:
                                matched_secrets.append(sub)
                            elif isinstance(sub, dict):
                                raw_items.append({**sub, "category": str(k)})

    for item in raw_items:
        if isinstance(item, str):
            if item not in categories:
                categories.append(item)
            findings_meta.append({"category": item, "count": 1})
            continue
        item_d = to_dict(item)
        cat = (
            item_d.get("category")
            or item_d.get("type")
            or item_d.get("entity_type")
            or item_d.get("label")
            or item_d.get("name")
            or "SENSITIVE_DATA"
        )
        cat_str = str(cat.value if hasattr(cat, "value") else cat)
        if cat_str not in categories:
            categories.append(cat_str)

        # Capture secret internally for verification & fallback redaction only
        for secret_key in ("matched_text", "value", "matched_value", "raw_value", "match", "text", "secret"):
            sec_val = item_d.get(secret_key)
            if isinstance(sec_val, str) and sec_val:
                matched_secrets.append(sec_val)

        # Capture character span if present
        start = item_d.get("start")
        end = item_d.get("end")
        if start is None or end is None:
            span = item_d.get("span")
            if isinstance(span, (tuple, list)) and len(span) == 2:
                start, end = span[0], span[1]
        if isinstance(start, int) and isinstance(end, int) and 0 <= start < end:
            raw_spans.append({"start": start, "end": end, "category": cat_str})

        # Metadata entry strictly omits raw secret values
        meta_entry: Dict[str, Any] = {"category": cat_str}
        for safe_key in ("severity", "confidence", "start", "end", "span", "count", "description", "rule"):
            if safe_key in item_d and item_d[safe_key] is not None:
                meta_entry[safe_key] = item_d[safe_key]
        findings_meta.append(meta_entry)

    return categories, findings_meta, raw_spans, matched_secrets


def _normalize_threats(threat_result: Any) -> Tuple[List[str], List[Dict[str, Any]]]:
    """Extract threat indicators and explanations."""
    if threat_result is None:
        raise ValueError("Threat detection result cannot be None.")

    indicators: List[str] = []
    details: List[Dict[str, Any]] = []

    if isinstance(threat_result, list):
        raw_list = threat_result
    else:
        d = to_dict(threat_result)
        raw_list = []
        for key in ("threats", "indicators", "findings", "matches", "alerts", "patterns"):
            if isinstance(d.get(key), list):
                raw_list = d[key]
                break
        if not raw_list and (d.get("is_threat") or d.get("threat_detected") or d.get("detected") or d.get("has_threats")):
            t_type = d.get("threat_type") or d.get("category") or "PROMPT_THREAT"
            indicators.append(str(t_type))
            details.append({
                "indicator": str(t_type),
                "severity": str(d.get("severity", "HIGH")),
                "explanation": str(
                    d.get("explanation")
                    or d.get("reason")
                    or d.get("description")
                    or "Suspicious prompt pattern detected."
                ),
            })

    for item in raw_list:
        if isinstance(item, str):
            if item not in indicators:
                indicators.append(item)
            details.append({
                "indicator": item,
                "severity": "HIGH",
                "explanation": f"Matched threat pattern: {item}",
            })
            continue
        item_d = to_dict(item)
        name = (
            item_d.get("category")
            or item_d.get("threat_type")
            or item_d.get("indicator")
            or item_d.get("name")
            or item_d.get("type")
            or item_d.get("rule_name")
            or "THREAT_INDICATOR"
        )
        name_str = str(name.value if hasattr(name, "value") else name)
        if name_str not in indicators:
            indicators.append(name_str)
        details.append({
            "indicator": name_str,
            "severity": str(item_d.get("severity", "HIGH")),
            "explanation": str(
                item_d.get("explanation")
                or item_d.get("description")
                or item_d.get("reason")
                or f"Threat indicator '{name_str}' triggered."
            ),
        })

    return indicators, details


def _scrub_audit_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively remove any forbidden raw prompt or secret keys from an audit record."""
    cleaned: Dict[str, Any] = {}
    for k, v in data.items():
        if str(k).lower() in FORBIDDEN_AUDIT_KEYS:
            continue
        if isinstance(v, dict):
            cleaned[k] = _scrub_audit_dict(v)
        elif isinstance(v, list):
            cleaned[k] = [
                _scrub_audit_dict(item) if isinstance(item, dict) else item
                for item in v
            ]
        else:
            cleaned[k] = v
    return cleaned


def record_audit_event(
    role: str,
    decision: str,
    risk_score: int,
    severity: str,
    categories: List[str],
    threat_indicators: List[str],
    reason: str,
    prompt_fingerprint: str = "",
    policy_result: Any = None,
    prompt: str = "",
    scan_result: Any = None,
) -> Dict[str, Any]:
    """Record a thread-safe, metadata-only audit event via core/audit_logger.py."""
    timestamp_iso = datetime.now(timezone.utc).isoformat()
    fp = str(prompt_fingerprint or (compute_prompt_fingerprint(prompt) if prompt else "sha256:none"))
    safe_event: Dict[str, Any] = {
        "timestamp": timestamp_iso,
        "role": str(role or "PUBLIC_ASSISTANT"),
        "decision": str(decision or "BLOCK").upper(),
        "action": str(decision or "BLOCK").upper(),
        "risk_score": max(0, min(100, int(risk_score))),
        "severity": str(severity or "NONE").upper(),
        "categories": [str(c) for c in categories],
        "threats": [str(t) for t in threat_indicators],
        "threat_count": len(threat_indicators),
        "prompt_fingerprint": fp,
        "reason": str(reason or ""),
    }

    context = {
        **safe_event,
        "agent_role": safe_event["role"],
        "score": safe_event["risk_score"],
        "risk_level": safe_event["severity"],
        "detected_categories": safe_event["categories"],
        "threat_indicators": safe_event["threats"],
        "explanation": safe_event["reason"],
        "result": _scrub_audit_dict(to_dict(policy_result)) if policy_result is not None else None,
        "prompt_text": prompt or "",
        "scan_result": scan_result or {
            "risk_level": severity,
            "risk_score": risk_score,
            "findings": [{"category": c, "risk_level": severity, "start": 0, "end": 0} for c in categories],
            "category_counts": {c: 1 for c in categories},
            "has_sensitive_data": bool(categories),
            "has_threats": bool(threat_indicators),
            "threat_counts": {t: 1 for t in threat_indicators},
        },
        "policy_result": policy_result or {
            "action": safe_event["decision"],
            "agent_role": safe_event["role"],
            "authorized": safe_event["decision"] != "BLOCK",
        },
    }

    with _AUDIT_LOCK:
        logged_to_core = False
        target_objs = [audit_logger]
        for attr in ("default_logger", "logger", "audit_log", "AUDIT_LOGGER", "_GLOBAL_AUDIT_LOGGER"):
            inst = getattr(audit_logger, attr, None)
            if inst is not None:
                target_objs.insert(0, inst)

        for fn_name in ("get_audit_logger", "get_logger"):
            getter = getattr(audit_logger, fn_name, None)
            if callable(getter):
                try:
                    inst = getter()
                    if inst is not None and inst not in target_objs:
                        target_objs.insert(0, inst)
                except Exception:
                    pass

        for obj in target_objs:
            if hasattr(obj, "log_scan_event") and callable(getattr(obj, "log_scan_event")):
                try:
                    obj.log_scan_event(
                        prompt_text=context["prompt_text"],
                        scan_result=context["scan_result"],
                        policy_result=context["policy_result"],
                    )
                    logged_to_core = True
                    break
                except Exception:
                    pass

            for fn_name in ("log_event", "record_event", "log_decision", "log", "append_event", "add_event"):
                fn = getattr(obj, fn_name, None)
                if callable(fn):
                    for fallback in (
                        (safe_event["role"], safe_event["decision"], safe_event["risk_score"], safe_event["categories"], safe_event["threats"], safe_event["reason"]),
                        (safe_event["decision"], safe_event["risk_score"], safe_event["role"], safe_event["categories"], safe_event["threats"]),
                        (safe_event,),
                    ):
                        try:
                            _call_with_matched_args(fn, context, fallback)
                            logged_to_core = True
                            break
                        except TypeError:
                            continue
                        except Exception:
                            break
            if logged_to_core:
                break

        _FALLBACK_AUDIT_EVENTS.append(dict(safe_event))
        return safe_event


def analyze_prompt_pipeline(prompt: Any, role: Any) -> Dict[str, Any]:
    """
    Execute the 5-step security gateway pipeline with strict input validation
    and fail-closed error handling:
      1. Sensitive-data detection
      2. Threat detection
      3. Risk scoring (0-100)
      4. Policy evaluation and overlap-safe redaction
      5. Privacy-preserving audit logging
    """
    valid_roles = get_available_roles()
    normalized_role = str(role).strip().upper() if isinstance(role, str) and role.strip() else ""
    max_len = get_max_prompt_length()

    # Validate prompt type and non-empty status
    if not isinstance(prompt, str) or not prompt.strip():
        return {
            "ok": False,
            "error": "Prompt cannot be empty. Please enter text to inspect.",
            "decision": "BLOCK",
            "risk_score": 0,
            "severity": "NONE",
            "role": normalized_role if normalized_role in valid_roles else "PUBLIC_ASSISTANT",
            "categories": [],
            "findings": [],
            "threat_indicators": [],
            "threat_details": [],
            "prompt_fingerprint": compute_prompt_fingerprint(""),
            "original_prompt": "",
            "sanitized_prompt": None,
            "explanation": "Empty or whitespace-only prompt rejected before analysis.",
        }

    fingerprint = compute_prompt_fingerprint(prompt)

    # Check for null bytes / malformed binary control sequences
    if "\x00" in prompt:
        reason = "Malformed input containing null bytes rejected by fail-closed input validator."
        record_audit_event(
            role=normalized_role or "PUBLIC_ASSISTANT",
            decision="BLOCK",
            risk_score=100,
            severity="CRITICAL",
            categories=[],
            threat_indicators=["MALFORMED_INPUT_NULL_BYTE"],
            reason=reason,
            prompt_fingerprint=fingerprint,
            prompt=prompt,
        )
        return {
            "ok": False,
            "error": reason,
            "decision": "BLOCK",
            "risk_score": 100,
            "severity": "CRITICAL",
            "role": normalized_role or "PUBLIC_ASSISTANT",
            "categories": [],
            "findings": [],
            "threat_indicators": ["MALFORMED_INPUT_NULL_BYTE"],
            "threat_details": [{"indicator": "MALFORMED_INPUT_NULL_BYTE", "severity": "CRITICAL", "explanation": reason}],
            "prompt_fingerprint": fingerprint,
            "original_prompt": "",
            "sanitized_prompt": None,
            "explanation": reason,
        }

    # Enforce maximum prompt length limit
    if len(prompt) > max_len:
        reason = f"Prompt length ({len(prompt)} characters) exceeds the maximum allowed limit of {max_len} characters."
        record_audit_event(
            role=normalized_role or "PUBLIC_ASSISTANT",
            decision="BLOCK",
            risk_score=100,
            severity="HIGH",
            categories=[],
            threat_indicators=["INPUT_LIMIT_EXCEEDED"],
            reason=reason,
            prompt_fingerprint=fingerprint,
            prompt=prompt,
        )
        return {
            "ok": False,
            "error": reason,
            "decision": "BLOCK",
            "risk_score": 100,
            "severity": "HIGH",
            "role": normalized_role or "PUBLIC_ASSISTANT",
            "categories": [],
            "findings": [],
            "threat_indicators": ["INPUT_LIMIT_EXCEEDED"],
            "threat_details": [{"indicator": "INPUT_LIMIT_EXCEEDED", "severity": "HIGH", "explanation": reason}],
            "prompt_fingerprint": fingerprint,
            "original_prompt": prompt[:200] + "... [TRUNCATED IN SESSION PREVIEW]",
            "sanitized_prompt": None,
            "explanation": reason,
        }

    # Validate agent role
    if normalized_role not in valid_roles:
        reason = f"Unrecognized agent role '{role}'. Fail-closed policy blocked execution."
        record_audit_event(
            role=normalized_role or "UNKNOWN_ROLE",
            decision="BLOCK",
            risk_score=100,
            severity="CRITICAL",
            categories=[],
            threat_indicators=["INVALID_AGENT_ROLE"],
            reason=reason,
            prompt_fingerprint=fingerprint,
            prompt=prompt,
        )
        return {
            "ok": False,
            "error": f"Unrecognized agent role '{role}'. Allowed roles: {', '.join(valid_roles)}.",
            "decision": "BLOCK",
            "risk_score": 100,
            "severity": "CRITICAL",
            "role": normalized_role or "UNKNOWN_ROLE",
            "categories": [],
            "findings": [],
            "threat_indicators": ["INVALID_AGENT_ROLE"],
            "threat_details": [{"indicator": "INVALID_AGENT_ROLE", "severity": "CRITICAL", "explanation": reason}],
            "prompt_fingerprint": fingerprint,
            "original_prompt": prompt,
            "sanitized_prompt": None,
            "explanation": reason,
        }

    try:
        # 1. Sensitive-data detection
        detection_res = run_detection(prompt)
        categories, findings_meta, raw_spans, matched_secrets = _normalize_findings(detection_res)

        # 2. Threat detection
        threat_res = run_threat_detection(prompt)
        threat_indicators, threat_details = _normalize_threats(threat_res)

        # 3. Risk scoring
        risk_res = run_risk_scoring(detection_res, threat_res, role=normalized_role, prompt=prompt)
        risk_score = _extract_risk_score(risk_res)
        severity = _extract_severity(risk_res, risk_score)
        risk_dict = to_dict(risk_res)

        # 4. Policy evaluation and redaction
        policy_res = run_policy_evaluation(
            prompt=prompt,
            role=normalized_role,
            detection_result=detection_res,
            threat_result=threat_res,
            risk_result=risk_res,
        )
        if policy_res is None:
            raise ValueError("Policy engine returned None.")
        policy_dict = to_dict(policy_res)

        raw_decision = (
            policy_dict.get("decision")
            or policy_dict.get("action")
            or policy_dict.get("status")
        )
        if hasattr(raw_decision, "value"):
            raw_decision = raw_decision.value
        decision = str(raw_decision).strip().upper() if raw_decision else ""

        if decision not in ("ALLOW", "REDACT", "BLOCK"):
            raise ValueError("Policy engine returned an invalid or unrecognized decision.")

        sanitized_prompt = (
            policy_dict.get("sanitized_prompt")
            or policy_dict.get("redacted_prompt")
            or policy_dict.get("sanitized_text")
            or policy_dict.get("redacted_text")
            or policy_dict.get("output_prompt")
            or policy_dict.get("processed_prompt")
        )

        if decision == "REDACT":
            # Prefer overlap-safe span redaction if spans are available and engine didn't already redact
            if sanitized_prompt is None or sanitized_prompt == prompt:
                det_dict = to_dict(detection_res)
                sanitized_prompt = (
                    det_dict.get("sanitized_prompt")
                    or det_dict.get("redacted_prompt")
                    or det_dict.get("redacted_text")
                )
            if (sanitized_prompt is None or sanitized_prompt == prompt) and raw_spans:
                sanitized_prompt = redact_spans_safely(prompt, raw_spans)
            if sanitized_prompt is None or sanitized_prompt == prompt:
                for redact_fn_name in ("redact_prompt", "redact_sensitive_data", "redact", "sanitize_prompt", "redact_text"):
                    redact_fn = getattr(detector, redact_fn_name, None) or getattr(policy_engine, redact_fn_name, None)
                    if callable(redact_fn):
                        try:
                            findings = detection_res.get("findings", []) if isinstance(detection_res, dict) else detection_res
                            sanitized_prompt = redact_fn(prompt, findings)
                            break
                        except TypeError:
                            try:
                                sanitized_prompt = redact_fn(prompt)
                                break
                            except Exception:
                                pass

            # Verify no matched secret remains in the sanitized output
            if isinstance(sanitized_prompt, str) and matched_secrets:
                for sec in matched_secrets:
                    if sec and sec in sanitized_prompt:
                        sanitized_prompt = sanitized_prompt.replace(sec, "[REDACTED:SENSITIVE_DATA]")

            if not isinstance(sanitized_prompt, str) or (categories and sanitized_prompt == prompt):
                raise RuntimeError("Redaction verification failed: sensitive content was not removed.")

        elif decision == "BLOCK":
            sanitized_prompt = None
        elif decision == "ALLOW":
            if sanitized_prompt is None:
                sanitized_prompt = prompt

        reasons_list = policy_dict.get("reasons")
        if isinstance(reasons_list, list) and reasons_list:
            explanation = "; ".join(str(r) for r in reasons_list)
        else:
            explanation = str(
                policy_dict.get("explanation")
                or policy_dict.get("reason")
                or policy_dict.get("message")
                or risk_dict.get("explanation")
                or f"Policy for role '{normalized_role}' evaluated findings and returned {decision}."
            )

        # 5. Privacy-preserving audit logging
        record_audit_event(
            role=normalized_role,
            decision=decision,
            risk_score=risk_score,
            severity=severity,
            categories=categories,
            threat_indicators=threat_indicators,
            reason=explanation,
            prompt_fingerprint=fingerprint,
            policy_result=policy_res,
            prompt=prompt,
            scan_result=detection_res,
        )

        return {
            "ok": True,
            "error": None,
            "decision": decision,
            "risk_score": risk_score,
            "severity": severity,
            "role": normalized_role,
            "categories": categories,
            "findings": findings_meta,
            "threat_indicators": threat_indicators,
            "threat_details": threat_details,
            "prompt_fingerprint": fingerprint,
            "original_prompt": prompt,
            "sanitized_prompt": sanitized_prompt,
            "explanation": explanation,
        }

    except Exception:
        # Never expose raw exception messages, stack traces, file paths, or secrets
        fail_reason = (
            "Internal security engine check failed. Fail-closed protection triggered: "
            "request blocked to prevent unsanitized data forwarding."
        )
        try:
            record_audit_event(
                role=normalized_role or "PUBLIC_ASSISTANT",
                decision="BLOCK",
                risk_score=100,
                severity="CRITICAL",
                categories=[],
                threat_indicators=["ENGINE_FAILURE_FAIL_CLOSED"],
                reason=fail_reason,
                prompt_fingerprint=fingerprint,
                prompt=prompt,
            )
        except Exception:
            pass
        return {
            "ok": False,
            "error": fail_reason,
            "decision": "BLOCK",
            "risk_score": 100,
            "severity": "CRITICAL",
            "role": normalized_role or "PUBLIC_ASSISTANT",
            "categories": [],
            "findings": [],
            "threat_indicators": ["ENGINE_FAILURE_FAIL_CLOSED"],
            "threat_details": [
                {
                    "indicator": "ENGINE_FAILURE_FAIL_CLOSED",
                    "severity": "CRITICAL",
                    "explanation": fail_reason,
                }
            ],
            "prompt_fingerprint": fingerprint,
            "original_prompt": prompt,
            "sanitized_prompt": None,
            "explanation": fail_reason,
        }


def get_role_policies() -> Dict[str, Dict[str, Any]]:
    """Inspect core/policy_engine.py and config/settings.py for real role policy definitions."""
    raw_policies: Dict[str, Any] = {}
    for module in (policy_engine, settings):
        for attr in ("AGENT_ROLES", "ROLE_POLICIES", "POLICIES", "DEFAULT_POLICIES", "AGENT_POLICIES", "ROLE_CONFIG"):
            val = getattr(module, attr, None)
            if isinstance(val, dict) and val:
                raw_policies = {str(k.value if hasattr(k, "value") else k): to_dict(v) for k, v in val.items()}
                break
        if raw_policies:
            break

    if not raw_policies:
        for fn_name in ("get_all_policies", "get_policies", "get_role_policies"):
            fn = getattr(policy_engine, fn_name, None)
            if callable(fn):
                try:
                    res = fn()
                    if isinstance(res, dict):
                        raw_policies = {str(k): to_dict(v) for k, v in res.items()}
                        break
                except Exception:
                    pass

    normalized: Dict[str, Dict[str, Any]] = {}
    for role in get_available_roles():
        p = raw_policies.get(role, {})
        if not p:
            for fn_name in ("get_policy", "get_role_policy", "get_policy_for_role"):
                fn = getattr(policy_engine, fn_name, None)
                if callable(fn):
                    try:
                        p = to_dict(fn(role))
                        break
                    except Exception:
                        pass
        normalized[role] = {
            "role": role,
            "description": str(
                p.get("description")
                or p.get("summary")
                or f"Security policy governing the {role} execution profile."
            ),
            "redact_categories": list(
                p.get("redact_categories")
                or p.get("redactable_categories")
                or p.get("redact")
                or p.get("redacted_categories")
                or []
            ),
            "block_categories": list(
                p.get("block_categories")
                or p.get("blocked_categories")
                or p.get("block")
                or []
            ),
            "allow_categories": list(
                p.get("allow_categories")
                or p.get("allowed_categories")
                or p.get("allow")
                or []
            ),
            "threat_action": str(
                p.get("threat_action")
                or p.get("on_threat")
                or p.get("threat_behavior")
                or "BLOCK on detected prompt injection / exfiltration threats"
            ),
            "risk_threshold_block": p.get("block_threshold") or p.get("max_risk_score") or p.get("risk_threshold") or p.get("max_allowed_risk"),
            "fail_closed": bool(p.get("fail_closed", True)),
            "raw": p,
        }
    return normalized


def clear_audit_events() -> None:
    """Clear in-memory audit events for deterministic test isolation."""
    with _AUDIT_LOCK:
        _FALLBACK_AUDIT_EVENTS.clear()
        target_objs = [audit_logger]
        for attr in ("default_logger", "logger", "audit_log", "AUDIT_LOGGER", "_GLOBAL_AUDIT_LOGGER"):
            inst = getattr(audit_logger, attr, None)
            if inst is not None:
                target_objs.insert(0, inst)
        for fn_name in ("get_audit_logger", "get_logger"):
            getter = getattr(audit_logger, fn_name, None)
            if callable(getter):
                try:
                    inst = getter()
                    if inst is not None and inst not in target_objs:
                        target_objs.insert(0, inst)
                except Exception:
                    pass
        for obj in target_objs:
            for fn_name in ("clear", "reset", "clear_events", "clear_logs"):
                fn = getattr(obj, fn_name, None)
                if callable(fn):
                    try:
                        fn()
                    except Exception:
                        pass
            for attr in ("_records", "events", "_events", "logs", "_logs", "entries"):
                val = getattr(obj, attr, None)
                if hasattr(val, "clear") and callable(getattr(val, "clear")):
                    try:
                        val.clear()
                    except Exception:
                        pass


def get_audit_events() -> Tuple[List[Dict[str, Any]], bool]:
    """
    Fetch real audit events from core/audit_logger.py (or fallback store) and
    strip any sensitive fields to guarantee metadata-only rendering.
    """
    with _AUDIT_LOCK:
        raw_events: List[Any] = []
        is_in_memory = True

        for attr in ("AUDIT_LOG_PATH", "LOG_FILE", "AUDIT_FILE", "PERSISTENT_LOG_PATH"):
            path_val = getattr(audit_logger, attr, None) or getattr(settings, attr, None)
            if path_val:
                is_in_memory = False

        target_objs = [audit_logger]
        for attr in ("default_logger", "logger", "audit_log", "AUDIT_LOGGER", "_GLOBAL_AUDIT_LOGGER"):
            inst = getattr(audit_logger, attr, None)
            if inst is not None:
                target_objs.insert(0, inst)
                if getattr(inst, "file_path", None) or getattr(inst, "log_path", None):
                    is_in_memory = False

        for fn_name in ("get_audit_logger", "get_logger"):
            getter = getattr(audit_logger, fn_name, None)
            if callable(getter):
                try:
                    inst = getter()
                    if inst is not None and inst not in target_objs:
                        target_objs.insert(0, inst)
                except Exception:
                    pass

        for obj in target_objs:
            for fn_name in ("get_records", "get_events", "get_logs", "get_audit_events", "list_events", "read_events", "get_history"):
                fn = getattr(obj, fn_name, None)
                if callable(fn):
                    try:
                        res = fn()
                        if isinstance(res, list):
                            raw_events = res
                            break
                    except Exception:
                        pass
            if raw_events:
                break
            for attr in ("_records", "events", "_events", "logs", "_logs", "entries"):
                val = getattr(obj, attr, None)
                if isinstance(val, (list, deque)):
                    raw_events = list(val)
                    break
            if raw_events:
                break

        if not raw_events and _FALLBACK_AUDIT_EVENTS:
            raw_events = list(_FALLBACK_AUDIT_EVENTS)

        safe_events: List[Dict[str, Any]] = []
        for ev in raw_events:
            clean = _scrub_audit_dict(to_dict(ev))
            cats = list(clean.get("categories") or clean.get("detected_categories") or list(clean.get("category_counts", {}).keys()))
            threats = list(clean.get("threats") or clean.get("threat_indicators") or list(clean.get("threat_counts", {}).keys()))
            decision = str(clean.get("decision") or clean.get("policy_action") or clean.get("action") or "BLOCK").upper()
            fp = str(
                clean.get("prompt_fingerprint")
                or clean.get("fingerprint")
                or (f"sha256:{clean['prompt_sha256'][:16]}" if clean.get("prompt_sha256") else "sha256:none")
            )
            safe_events.append({
                "timestamp": str(clean.get("timestamp") or clean.get("timestamp_utc") or clean.get("created_at") or clean.get("time") or ""),
                "role": str(clean.get("role") or clean.get("agent_role") or "PUBLIC_ASSISTANT"),
                "decision": decision,
                "action": decision,
                "risk_score": int(
                    clean.get("risk_score")
                    if isinstance(clean.get("risk_score"), (int, float))
                    else clean.get("score", 0) or 0
                ),
                "severity": str(clean.get("severity") or clean.get("risk_level") or "NONE").upper(),
                "categories": cats,
                "threats": threats,
                "threat_count": int(
                    clean.get("threat_count")
                    if isinstance(clean.get("threat_count"), int)
                    else len(threats)
                ),
                "prompt_fingerprint": fp,
                "reason": str(clean.get("reason") or clean.get("explanation") or ""),
            })

        return safe_events, is_in_memory


def export_audit_jsonl() -> str:
    """Serialize metadata-only audit events as valid JSONL (one JSON object per line)."""
    with _AUDIT_LOCK:
        events, _ = get_audit_events()
        if not events:
            return ""
        return "\n".join(json.dumps(_scrub_audit_dict(ev), sort_keys=True) for ev in events)
