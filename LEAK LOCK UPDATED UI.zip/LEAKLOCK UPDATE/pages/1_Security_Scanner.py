"""
LEAKLOCK — Page 1: Interactive Security Scanner
"""

from __future__ import annotations

import streamlit as st

from services import (
    analyze_prompt_pipeline,
    get_available_roles,
    load_sample_prompts,
)

st.set_page_config(
    page_title="Security Scanner | LEAKLOCK",
    page_icon="🔍",
    layout="wide",
)


def _init_session_state() -> None:
    roles = get_available_roles()
    if "selected_agent_role" not in st.session_state or st.session_state["selected_agent_role"] not in roles:
        st.session_state["selected_agent_role"] = roles[0] if roles else "PUBLIC_ASSISTANT"
    if "scanner_prompt_input" not in st.session_state:
        st.session_state["scanner_prompt_input"] = ""
    if "scanner_last_result" not in st.session_state:
        st.session_state["scanner_last_result"] = None


def _clear_scanner() -> None:
    st.session_state["scanner_prompt_input"] = ""
    st.session_state["scanner_last_result"] = None


def render_scanner_page() -> None:
    _init_session_state()
    roles = get_available_roles()
    samples = load_sample_prompts()

    st.title("🔍 Interactive Security Scanner")
    st.markdown(
        "Inspect user prompts before they leave your boundary. All detection, risk scoring, "
        "and policy enforcement execute locally."
    )

    with st.container(border=True):
        top_col1, top_col2 = st.columns([1, 2])

        with top_col1:
            selected_role = st.selectbox(
                "Active Agent Role",
                options=roles,
                index=roles.index(st.session_state["selected_agent_role"])
                if st.session_state["selected_agent_role"] in roles
                else 0,
                help="Select the security profile under which the prompt will be evaluated.",
            )
            st.session_state["selected_agent_role"] = selected_role

        with top_col2:
            if samples:
                sample_labels = ["-- Select a synthetic sample prompt --"] + [
                    f"[{s.get('category', s.get('type', 'SAMPLE'))}] {s.get('title', s.get('name', s.get('id', f'Sample #{i+1}')))}"
                    for i, s in enumerate(samples)
                ]
                chosen_idx = st.selectbox(
                    "Load Synthetic Sample (Optional)",
                    options=range(len(sample_labels)),
                    format_func=lambda idx: sample_labels[idx],
                )
                if chosen_idx > 0:
                    sample_obj = samples[chosen_idx - 1]
                    sample_text = str(sample_obj.get("prompt") or sample_obj.get("prompt_text") or sample_obj.get("text") or "")
                    if st.button("Load Selected Sample into Editor"):
                        st.session_state["scanner_prompt_input"] = sample_text
                        sample_role = sample_obj.get("role") or sample_obj.get("agent_role")
                        if sample_role in roles:
                            st.session_state["selected_agent_role"] = sample_role
                        st.rerun()
            else:
                st.caption("No sample prompts found in `data/sample_prompts.json`.")

        prompt_text = st.text_area(
            "Prompt to Inspect",
            value=st.session_state["scanner_prompt_input"],
            height=180,
            placeholder="Paste or type a prompt containing credentials, PII, internal notes, or instructions...",
        )
        st.session_state["scanner_prompt_input"] = prompt_text

        btn_col1, btn_col2, _ = st.columns([1, 1, 4])
        analyze_clicked = btn_col1.button("🛡️ Analyze Prompt", type="primary", use_container_width=True)
        btn_col2.button("🧹 Clear / Reset", on_click=_clear_scanner, use_container_width=True)

    if analyze_clicked:
        if not prompt_text or not prompt_text.strip():
            st.warning("Please enter a non-empty prompt before running security analysis.")
            st.session_state["scanner_last_result"] = None
        else:
            with st.spinner("Running local detection, threat analysis, risk scoring, and policy enforcement..."):
                result = analyze_prompt_pipeline(prompt=prompt_text, role=selected_role)
                st.session_state["scanner_last_result"] = result

    result = st.session_state.get("scanner_last_result")
    if result is None:
        st.info("Enter a prompt above and click **Analyze Prompt** to view the gateway decision and risk breakdown.")
        return

    st.divider()
    st.subheader("Security Gate Decision & Risk Assessment")

    if not result.get("ok"):
        st.error(f"**Fail-Closed Security Enforcement:** {result.get('error')}")

    decision = result.get("decision", "BLOCK")
    risk_score = result.get("risk_score", 0)
    severity = result.get("severity", "NONE")
    role_used = result.get("role", selected_role)
    categories = result.get("categories", [])
    threat_indicators = result.get("threat_indicators", [])

    # Distinct accessible visual banner for ALLOW / REDACT / BLOCK
    if decision == "ALLOW":
        st.success(
            f"### ✅ DECISION: ALLOW\n"
            f"**Policy Explanation:** {result.get('explanation')}\n\n"
            f"This request satisfied the **{role_used}** policy and is approved for downstream processing."
        )
    elif decision == "REDACT":
        st.warning(
            f"### ⚠️ DECISION: REDACT\n"
            f"**Policy Explanation:** {result.get('explanation')}\n\n"
            f"Sensitive content was sanitized according to the **{role_used}** policy. "
            f"Only the redacted payload below may be forwarded."
        )
    else:
        st.error(
            f"### 🛑 DECISION: BLOCK\n"
            f"**Policy Explanation:** {result.get('explanation')}\n\n"
            f"**CRITICAL: This request is blocked by the {role_used} policy and MUST NOT be forwarded to any downstream AI service.**"
        )

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Final Decision", decision)
    m2.metric("Risk Score (0–100)", f"{risk_score} / 100")
    m3.metric("Risk Severity", severity)
    m4.metric("Agent Role Evaluated", role_used)

    st.progress(min(100, max(0, int(risk_score))) / 100.0, text=f"Calculated Risk Score: {risk_score}/100 ({severity})")

    # Findings & Threat Breakdown
    det_col, thr_col = st.columns(2)
    with det_col:
        with st.container(border=True):
            st.markdown("#### 🔎 Detected Sensitive Categories")
            if categories:
                st.markdown(", ".join(f"`{c}`" for c in categories))
                findings = result.get("findings", [])
                if findings:
                    st.dataframe(findings, use_container_width=True, hide_index=True)
            else:
                st.caption("No sensitive data categories detected.")

    with thr_col:
        with st.container(border=True):
            st.markdown("#### 🚨 Threat Indicators & Heuristics")
            if threat_indicators:
                st.markdown(", ".join(f"`{t}`" for t in threat_indicators))
                threat_details = result.get("threat_details", [])
                if threat_details:
                    st.dataframe(threat_details, use_container_width=True, hide_index=True)
            else:
                st.caption("No prompt injection, jailbreak, or exfiltration threat indicators detected.")

    # Payload Comparison (Session-Only Original vs. Sanitized Output)
    st.subheader("Payload Inspection & Forwarding Preview")
    pay_col1, pay_col2 = st.columns(2)

    with pay_col1:
        with st.container(border=True):
            st.markdown("**Sanitized Output Preview (Downstream Payload)**")
            if decision == "BLOCK":
                st.error(
                    "🚫 **PAYLOAD SUPPRESSED (BLOCKED)** — Request execution halted. "
                    "Nothing will be transmitted downstream."
                )
            elif decision == "REDACT":
                st.caption("Exact sanitized payload produced by the engine for downstream transmission:")
                st.code(result.get("sanitized_prompt") or "", language="text")
            else:
                st.caption("Approved output according to active policy:")
                st.code(result.get("sanitized_prompt") or "", language="text")

    with pay_col2:
        with st.expander("View Original Input Prompt (Current Session UI Only — Never Logged)", expanded=False):
            st.caption(
                "Displayed solely within your active browser session for comparison. "
                "LEAKLOCK never writes raw prompts or secret values to the audit log."
            )
            st.code(result.get("original_prompt") or "", language="text")


def main() -> None:
    render_scanner_page()


if __name__ == "__main__":
    render_scanner_page()