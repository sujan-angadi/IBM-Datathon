# Configuration package for LEAKLOCK.
