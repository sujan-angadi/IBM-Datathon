"""
LEAKLOCK — Security Scanner Page
Interactive prompt security scanner with sensitive-data detection,
threat analysis, policy evaluation, and privacy-conscious audit logging.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st

from core.detector import DEFAULT_CATEGORY_RISK_MAP, detect_sensitive_data
from core.policy_engine import AGENT_ROLES, evaluate_policy
from core.audit_logger import get_audit_logger

# Resolve sample data path relative to project root (portable across OS)
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
SAMPLE_DATA_PATH = _PROJECT_ROOT / "data" / "sample_prompts.json"


def _load_sample_prompts() -> List[Dict[str, Any]]:
    """Loads synthetic sample prompts from disk safely (supports dict or list JSON)."""
    if not SAMPLE_DATA_PATH.exists():
        return []
    try:
        with SAMPLE_DATA_PATH.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                for key in ("samples", "prompts", "items"):
                    if isinstance(data.get(key), list):
                        return data[key]
            return []
    except (OSError, json.JSONDecodeError):
        return []


def main() -> None:
    st.set_page_config(
        page_title="Security Scanner | LEAKLOCK",
        page_icon="🛡️",
        layout="wide",
    )
    st.title("🛡️ Security Scanner")
    st.caption("LEAKLOCK — Real-Time AI Prompt Security Analysis")

    # --- Sidebar controls ---
    st.sidebar.markdown("### Scanner Configuration")

    # Agent role selector
    role_options = list(AGENT_ROLES.keys())
    selected_role = st.sidebar.selectbox(
        "Agent Role",
        options=role_options,
        index=0,
        help="Select the agent role for policy evaluation. Different roles have different clearance levels.",
    )
    role_info = AGENT_ROLES[selected_role]
    st.sidebar.caption(role_info["description"])

    # AI analysis toggle
    enable_ai = st.sidebar.checkbox(
        "Enable Hybrid AI Analysis",
        value=False,
        help="Runs additional contextual analysis on pre-redacted text to detect coercive/exfiltration intent.",
    )

    st.sidebar.divider()
    st.sidebar.markdown("### Sample Prompts")
    samples = _load_sample_prompts()

    selected_sample_text = ""
    if samples:
        sample_titles = ["— Select a sample prompt —"] + [
            s.get("title", s.get("id", "Untitled")) for s in samples
        ]
        sample_choice = st.sidebar.selectbox("Load Sample", options=sample_titles)
        if sample_choice != sample_titles[0]:
            idx = sample_titles.index(sample_choice) - 1
            selected_sample_text = samples[idx].get(
                "prompt_text", samples[idx].get("prompt", "")
            )
    else:
        st.sidebar.info("No sample prompts found.")

    # --- Main input area ---
    st.markdown("### Enter Prompt for Security Analysis")
    prompt_text = st.text_area(
        "Prompt Text",
        value=selected_sample_text,
        height=150,
        placeholder="Type or paste a prompt to scan for sensitive data, threats, and policy violations...",
    )

    scan_button = st.button("🔍 Scan Prompt", type="primary", use_container_width=True)

    if scan_button:
        if not prompt_text or not prompt_text.strip():
            st.warning("Please enter a prompt to scan.")
            return

        # --- Run detection pipeline ---
        with st.spinner("Scanning prompt for sensitive data and threats..."):
            scan_result = detect_sensitive_data(
                prompt_text,
                enable_ai_analysis=enable_ai,
            )
            policy_result = evaluate_policy(prompt_text, scan_result, selected_role)

        # Log audit event (privacy-preserving)
        audit_logger = get_audit_logger()
        audit_logger.log_scan_event(prompt_text, scan_result, policy_result)

        # --- Display results ---
        st.divider()
        st.markdown("### Scan Results")

        # Policy decision banner
        action = policy_result["action"]
        if action == "ALLOW":
            st.success(f"✅ **Policy Decision: ALLOW** — Role: {selected_role}")
        elif action == "REDACT":
            st.warning(f"⚠️ **Policy Decision: REDACT** — Role: {selected_role}")
        else:
            st.error(f"🚫 **Policy Decision: BLOCK** — Role: {selected_role}")

        # Metrics row
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Risk Level", scan_result["risk_level"])
        with col2:
            st.metric("Risk Score", f"{scan_result['risk_score']}/100")
        with col3:
            st.metric("Findings", len(scan_result["findings"]))
        with col4:
            st.metric("Threats", len(scan_result.get("threats", [])))

        # Summary
        st.info(scan_result["summary"])

        # Policy reasons
        if policy_result["reasons"]:
            st.markdown("#### Policy Evaluation Details")
            for reason in policy_result["reasons"]:
                st.write(f"• {reason}")

        # Findings detail
        if scan_result["findings"]:
            st.markdown("#### Sensitive Data Findings")
            findings_display = []
            for f in scan_result["findings"]:
                findings_display.append(
                    {
                        "Category": f["category"],
                        "Risk Level": f["risk_level"],
                        "Start": f["start"],
                        "End": f["end"],
                        "Length": f["end"] - f["start"],
                    }
                )
            st.table(findings_display)

        # Threats detail
        if scan_result.get("threats"):
            st.markdown("#### Prompt Threats Detected")
            threats_display = []
            for t in scan_result["threats"]:
                threats_display.append(
                    {
                        "Category": t["category"],
                        "Severity": t["severity"],
                        "Description": t["description"],
                    }
                )
            st.table(threats_display)

        # Risk breakdown
        risk_breakdown = scan_result.get("risk_breakdown", {})
        if risk_breakdown.get("factors"):
            st.markdown("#### Risk Score Breakdown")
            for factor in risk_breakdown["factors"]:
                st.write(
                    f"• **{factor['factor']}** (+{factor['points']} pts): {factor['detail']}"
                )
            st.caption(risk_breakdown.get("explanation", ""))

        # Sanitized prompt output
        st.markdown("#### Sanitized Output")
        if action == "BLOCK":
            st.code(policy_result["sanitized_prompt"], language="text")
        elif action == "REDACT":
            st.code(policy_result["sanitized_prompt"], language="text")
        else:
            st.code(prompt_text, language="text")

        # Hardware signals
        st.markdown("#### Hardware Compatibility Signals")
        hw_col1, hw_col2 = st.columns(2)
        with hw_col1:
            st.write(
                f"**Risk Encoding:** `{scan_result.get('hardware_risk_code', 'N/A')}`"
            )
        with hw_col2:
            st.write(
                f"**Policy Signal:** `{policy_result.get('hardware_policy_signal', 'N/A')}`"
            )

        st.caption(
            f"Analysis Mode: {scan_result.get('analysis_mode', 'LOCAL_RULES_ONLY')}"
        )


if __name__ == "__main__":
    main()