"""
LEAKLOCK — Policy Manager Page
Displays agent roles, policy clearances, and enforcement capabilities.
"""

from __future__ import annotations

import streamlit as st

from core.policy_engine import AGENT_ROLES


def main() -> None:
    st.set_page_config(
        page_title="Policy Manager | LEAKLOCK",
        page_icon="⚖️",
        layout="wide",
    )
    st.title("⚖️ Policy Manager")
    st.caption("LEAKLOCK — Role-Based Agent Authorization & Policy Enforcement")

    st.markdown(
        "LEAKLOCK enforces deterministic policy decisions (**ALLOW**, **REDACT**, or **BLOCK**) "
        "based on the caller's agent role clearance and the detected sensitive data categories."
    )

    st.divider()

    # --- Agent Roles ---
    st.markdown("### Agent Role Profiles")
    st.write(
        "Each agent role defines which sensitive-data categories can be transmitted, "
        "which must be redacted, and which trigger an immediate block."
    )

    for role_key, role_spec in AGENT_ROLES.items():
        with st.expander(f"**{role_key}** — {role_spec['label']}", expanded=False):
            st.markdown(f"**Description:** {role_spec['description']}")
            st.markdown(f"**Maximum Allowed Risk:** `{role_spec['max_allowed_risk']}`")

            col_r, col_b = st.columns(2)
            with col_r:
                redactable = sorted(role_spec.get("redactable_categories", set()))
                if redactable:
                    st.markdown("**Redactable Categories:**")
                    for cat in redactable:
                        st.write(f"  • `{cat}`")
                else:
                    st.markdown("**Redactable Categories:** _(none — fails closed)_")
            with col_b:
                blocked = sorted(role_spec.get("blocked_categories", set()))
                if blocked:
                    st.markdown("**Blocked Categories:**")
                    for cat in blocked:
                        st.write(f"  • `{cat}`")
                else:
                    st.markdown("**Blocked Categories:** _(none)_")

    st.divider()

    # --- Enforcement Actions Reference ---
    st.markdown("### Enforcement Actions")
    actions = [
        {
            "Action": "ALLOW",
            "Hardware Opcode": "2'b00",
            "Description": "No policy violations detected. Prompt passes unmodified.",
        },
        {
            "Action": "REDACT",
            "Hardware Opcode": "2'b01",
            "Description": "Sensitive spans replaced with [REDACTED_<CATEGORY>] before transmission.",
        },
        {
            "Action": "BLOCK",
            "Hardware Opcode": "2'b10",
            "Description": "Transmission prohibited. Prompt never leaves the gateway.",
        },
    ]
    st.table(actions)

    st.info(
        "Policy evaluation runs automatically in the **Security Scanner**. "
        "Select an agent role and scan a prompt to see the policy decision in action."
    )


if __name__ == "__main__":
    main()
