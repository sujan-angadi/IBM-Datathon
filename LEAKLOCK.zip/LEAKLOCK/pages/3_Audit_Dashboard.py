"""
LEAKLOCK — Audit Dashboard Page
Displays privacy-preserving audit records from the in-memory audit logger.
"""

from __future__ import annotations

import streamlit as st

from core.audit_logger import get_audit_logger


def main() -> None:
    st.set_page_config(
        page_title="Audit Dashboard | LEAKLOCK",
        page_icon="📊",
        layout="wide",
    )
    st.title("📊 Security Audit Dashboard")
    st.caption("LEAKLOCK — Privacy-Conscious Security Telemetry")

    st.markdown(
        "The audit log records **metadata only** — SHA-256 prompt fingerprints, "
        "category counts, risk scores, and policy decisions. "
        "**Raw prompts and matched secrets are never stored.**"
    )

    audit_logger = get_audit_logger()
    records = audit_logger.get_records()

    st.divider()

    # --- Summary metrics ---
    st.markdown("### Gateway Telemetry Summary")
    total_scans = len(records)
    blocked_count = sum(1 for r in records if r.get("policy_action") == "BLOCK")
    redacted_count = sum(1 for r in records if r.get("policy_action") == "REDACT")
    allowed_count = sum(1 for r in records if r.get("policy_action") == "ALLOW")
    sensitive_count = sum(1 for r in records if r.get("has_sensitive_data"))

    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric(label="Total Scans", value=str(total_scans))
    m2.metric(label="Allowed", value=str(allowed_count))
    m3.metric(label="Redacted", value=str(redacted_count))
    m4.metric(label="Blocked", value=str(blocked_count))
    m5.metric(label="Sensitive Detected", value=str(sensitive_count))

    st.divider()

    # --- Audit records table ---
    st.markdown("### Recent Audit Events")
    if not records:
        st.info(
            "No audit events recorded yet. "
            "Use the **Security Scanner** to scan prompts and generate audit telemetry."
        )
    else:
        display_records = []
        for r in records:
            display_records.append(
                {
                    "Event ID": r.get("event_id", "N/A"),
                    "Timestamp (UTC)": r.get("timestamp_utc", "N/A"),
                    "Agent Role": r.get("agent_role", "N/A"),
                    "Action": r.get("policy_action", "N/A"),
                    "Risk Level": r.get("risk_level", "N/A"),
                    "Risk Score": r.get("risk_score", 0),
                    "Findings": r.get("finding_count", 0),
                    "Has Threats": "Yes" if r.get("has_threats") else "No",
                }
            )
        st.table(display_records)

        # --- Category breakdown ---
        all_categories: dict[str, int] = {}
        for r in records:
            for cat, count in r.get("category_counts", {}).items():
                all_categories[cat] = all_categories.get(cat, 0) + count
        if all_categories:
            st.markdown("### Cumulative Category Distribution")
            cat_display = [
                {"Category": cat, "Total Detections": count}
                for cat, count in sorted(all_categories.items())
            ]
            st.table(cat_display)

    st.divider()

    # --- Controls ---
    col1, col2 = st.columns(2)
    with col1:
        if st.button("🗑️ Clear Audit Log", type="secondary"):
            audit_logger.clear()
            st.rerun()
    with col2:
        st.caption(
            "Audit records are stored in-memory only for this session. "
            "They are not persisted to disk by default."
        )


if __name__ == "__main__":
    main()
