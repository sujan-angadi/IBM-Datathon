"""
LEAKLOCK — About Page
Project information, roadmap, and architecture overview.
"""

from __future__ import annotations

import streamlit as st

from config import settings


def main() -> None:
    st.set_page_config(
        page_title="About | LEAKLOCK",
        page_icon="ℹ️",
        layout="wide",
    )
    st.title("ℹ️ About LEAKLOCK")
    st.subheader(settings.APP_THEME)

    st.markdown("### Purpose")
    st.write(
        "Organizations adopting generative AI face a critical challenge: employees and applications can inadvertently "
        "paste sensitive customer records, proprietary source code, or cryptographic keys into external AI prompts. "
        "**LEAKLOCK** acts as a transparent AI Data Protection Gateway that inspects prompts before they leave the boundary, "
        "applying deterministic **ALLOW**, **REDACT**, or **BLOCK** policies."
    )
    st.divider()

    st.markdown("### Five-Phase Development Roadmap")
    st.markdown(
        "- **Phase 1 — Foundation and Streamlit UI (Completed):** Modular directory hierarchy, "
        "configuration management, synthetic test dataset, automated structural tests, and multi-page Streamlit interface.\n"
        "- **Phase 2 — Detection, Policy & Audit Engine (Current Phase):** Regex and heuristic detectors in `core/` identify "
        "PII, credentials, and sensitive patterns. Policy engine enforces role-based ALLOW/REDACT/BLOCK decisions. "
        "Privacy-conscious audit logger records metadata-only telemetry. Contextual risk scoring with transparent factor breakdown.\n"
        "- **Phase 3 — Custom Verilog Hardware Controller (`leaklock_controller.v`) (Planned):** Design, simulate (Icarus Verilog / GTKWave), "
        "and synthesize (Yosys) a deterministic hardware policy decision block.\n"
        "- **Phase 4 — Advanced Threat Intelligence (Planned):** Enhanced prompt injection detection, "
        "ML-based anomaly detection, and external threat feed integration.\n"
        "- **Phase 5 — End-to-End Integration & Deployment Readiness (Planned):** Unify software and hardware simulation bridges, "
        "complete stress testing, and package for enterprise Linux deployment."
    )
    st.divider()

    col_hw, col_sw = st.columns(2)
    with col_hw:
        st.markdown("### Planned Hardware Controller (`leaklock_controller.v`)")
        st.write(
            "In Phase 3, LEAKLOCK will include a custom Verilog RTL module that accepts encoded risk metadata bitmasks "
            "and active policy configuration bits, returning a deterministic 2-bit action code (`ALLOW`, `REDACT`, or `BLOCK`) "
            "within a single clock cycle."
        )
    with col_sw:
        st.markdown("### Software-Only Fallback Architecture")
        st.write(
            "LEAKLOCK is architected so that hardware tools (Icarus Verilog, GTKWave, Yosys, or FPGA boards) are strictly optional. "
            "A clean Python interface in `services/` guarantees that if hardware simulation is unavailable, a pure-Python "
            "decision service executes identical policy logic seamlessly."
        )

    st.divider()
    st.markdown("### Current Capabilities")
    st.markdown(
        f"- **Version:** {settings.APP_VERSION}\n"
        f"- **Phase:** {settings.CURRENT_PHASE}\n"
        f"- **Scanner:** {'✅ Active' if settings.SCANNER_ENABLED else '❌ Disabled'}\n"
        f"- **Policy Engine:** {'✅ Active' if settings.POLICY_ENGINE_ENABLED else '❌ Disabled'}\n"
        f"- **Audit Logging:** {'✅ Active' if settings.AUDIT_LOGGING_ENABLED else '❌ Disabled'}\n"
        f"- **Hardware Controller:** {'✅ Active' if settings.HARDWARE_CONTROLLER_ENABLED else '⏳ Planned (Phase 3)'}\n"
        f"- **Decision Backend:** `{settings.DECISION_BACKEND}`"
    )


if __name__ == "__main__":
    main()
