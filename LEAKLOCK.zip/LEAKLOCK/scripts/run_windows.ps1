# LEAKLOCK — Windows 11 Startup Script (PowerShell)
# Requires Python 3.10 or later installed and on PATH.
# Run from the project root or scripts\ directory.
# Usage: powershell -ExecutionPolicy Bypass -File scripts\run_windows.ps1
#        powershell -ExecutionPolicy Bypass -File scripts\run_windows.ps1 -SkipTests

param(
    [switch]$SkipTests
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ProjectRoot = Split-Path -Parent $ScriptDir

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  LEAKLOCK - AI Data Protection Gateway" -ForegroundColor Cyan
Write-Host "  IBM Z Datathon 2026" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# --- Python version check ---
$PythonCmd = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        $parts = $ver.Split(".")
        if ($parts.Length -ge 2 -and [int]$parts[0] -ge 3 -and [int]$parts[1] -ge 10) {
            $PythonCmd = $cmd
            break
        }
    } catch {}
}

if ($null -eq $PythonCmd) {
    Write-Host "ERROR: Python 3.10 or later is required." -ForegroundColor Red
    Write-Host "  Download from: https://www.python.org/downloads/"
    Write-Host "  Ensure 'Add Python to PATH' is checked during installation."
    exit 1
}

$pyVersion = & $PythonCmd --version
Write-Host "Using Python: $pyVersion" -ForegroundColor Green

# --- Virtual environment ---
$VenvDir = Join-Path $ProjectRoot ".venv"
if (-not (Test-Path $VenvDir)) {
    Write-Host "Creating virtual environment at .venv ..." -ForegroundColor Yellow
    & $PythonCmd -m venv $VenvDir
}

# Activate venv
$ActivateScript = Join-Path $VenvDir "Scripts\Activate.ps1"
if (-not (Test-Path $ActivateScript)) {
    Write-Host "ERROR: Virtual environment activation script not found: $ActivateScript" -ForegroundColor Red
    exit 1
}
. $ActivateScript

# --- Install dependencies ---
Write-Host "Installing / verifying dependencies ..." -ForegroundColor Yellow
python -m pip install -r (Join-Path $ProjectRoot "requirements.txt") --quiet

# --- Load optional .env ---
$EnvFile = Join-Path $ProjectRoot ".env"
if (Test-Path $EnvFile) {
    Write-Host "Loading environment from .env ..." -ForegroundColor Yellow
    Get-Content $EnvFile | ForEach-Object {
        if ($_ -match '^\s*([^#\s][^=]*)=(.*)$') {
            $key = $matches[1].Trim()
            $val = $matches[2].Trim()
            [System.Environment]::SetEnvironmentVariable($key, $val, "Process")
        }
    }
}

# --- Run tests (optional) ---
if (-not $SkipTests) {
    Write-Host ""
    Write-Host "Running security test suite ..." -ForegroundColor Yellow
    python -m pytest (Join-Path $ProjectRoot "tests") -q --tb=short
    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "WARNING: Some tests failed. The app will still start." -ForegroundColor Yellow
        Write-Host ""
    }
}

# --- Start Streamlit ---
$Host_ = if ($env:LEAKLOCK_HOST) { $env:LEAKLOCK_HOST } else { "127.0.0.1" }
$Port  = if ($env:LEAKLOCK_PORT) { $env:LEAKLOCK_PORT } else { "8501" }

Write-Host ""
Write-Host "Starting LEAKLOCK on http://${Host_}:${Port}" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop." -ForegroundColor Green
Write-Host ""

& streamlit run (Join-Path $ProjectRoot "app.py") `
    --server.address=$Host_ `
    --server.port=$Port `
    --server.headless=true `
    --browser.gatherUsageStats=false
