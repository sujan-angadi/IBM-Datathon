#!/usr/bin/env bash
# LEAKLOCK — Linux Startup Script
# Tested on Rocky Linux 10.x and Ubuntu 22.04+
# Requires Python 3.10 or later.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "============================================================"
echo "  LEAKLOCK — AI Data Protection Gateway"
echo "  IBM Z Datathon 2026"
echo "============================================================"
echo ""

# --- Python version check ---
PYTHON_CMD=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then
        version=$("$cmd" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null || true)
        major=$(echo "$version" | cut -d. -f1)
        minor=$(echo "$version" | cut -d. -f2)
        if [ "${major:-0}" -ge 3 ] && [ "${minor:-0}" -ge 10 ]; then
            PYTHON_CMD="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON_CMD" ]; then
    echo "ERROR: Python 3.10 or later is required."
    echo "  On Rocky Linux 10: sudo dnf install python3"
    echo "  On Ubuntu/Debian:   sudo apt install python3"
    exit 1
fi

echo "Using Python: $($PYTHON_CMD --version)"

# --- Virtual environment ---
VENV_DIR="$PROJECT_ROOT/.venv"
if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment at .venv ..."
    "$PYTHON_CMD" -m venv "$VENV_DIR"
fi

# Activate venv
# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

# --- Install dependencies ---
echo "Installing / verifying dependencies ..."
pip install --quiet -r "$PROJECT_ROOT/requirements.txt"

# --- Load optional .env ---
ENV_FILE="$PROJECT_ROOT/.env"
if [ -f "$ENV_FILE" ]; then
    echo "Loading environment from .env ..."
    # Export only simple KEY=VALUE lines (no comments, no empty lines)
    while IFS='=' read -r key value; do
        [[ "$key" =~ ^[[:space:]]*# ]] && continue
        [[ -z "$key" ]] && continue
        export "$key=$value"
    done < "$ENV_FILE"
fi

# --- Run tests (optional, use --skip-tests to bypass) ---
if [[ "${1:-}" != "--skip-tests" ]]; then
    echo ""
    echo "Running security test suite ..."
    python -m pytest "$PROJECT_ROOT/tests/" -q --tb=short || {
        echo ""
        echo "WARNING: Some tests failed. Review the output above."
        echo "The application will still start, but results may be unreliable."
        echo ""
    }
fi

# --- Start Streamlit ---
HOST="${LEAKLOCK_HOST:-127.0.0.1}"
PORT="${LEAKLOCK_PORT:-8501}"

echo ""
echo "Starting LEAKLOCK on http://${HOST}:${PORT}"
echo "Press Ctrl+C to stop."
echo ""

exec streamlit run "$PROJECT_ROOT/app.py" \
    --server.address="$HOST" \
    --server.port="$PORT" \
    --server.headless=true \
    --browser.gatherUsageStats=false
