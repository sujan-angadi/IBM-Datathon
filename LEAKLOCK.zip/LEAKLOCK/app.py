"""
LEAKLOCK — AI Data Protection Gateway
IBM Z Datathon 2026
Main Streamlit Entrypoint (Phase 1 Structure + Phase 2 Enhancements Connected)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st

from core.detector import DEFAULT_CATEGORY_RISK_MAP
from core.policy_engine import AGENT_ROLES

# Resolve project root portably (works regardless of cwd or OS)
_PROJECT_ROOT = Path(__file__).resolve().parent
_SAMPLE_DATA_PATH = _PROJECT_ROOT / "data" / "sample_prompts.json"


def load_sample_prompts() -> List[Dict[str, Any]]:
    """Loads synthetic sample prompts from disk safely."""
    if not _SAMPLE_DATA_PATH.exists():
        return []
    try:
        with _SAMPLE_DATA_PATH.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                for key in ("samples", "prompts", "items"):
                    if isinstance(data.get(key), list):
                        return data[key]
            return []
    except (OSError, json.JSONDecodeError):
        return []


st.set_page_config(
    page_title="LEAKLOCK — AI Data Protection Gateway",
    page_icon="🔒",
    layout="wide",
)


def main() -> None:
    st.title("🔒 LEAKLOCK — AI Data Protection Gateway")
    st.subheader("IBM Z Datathon 2026 • Enterprise Prompt Security, Policy & Governance")

    st.markdown(
        """
        **LEAKLOCK** inspects outbound prompts before they leave the enterprise boundary
        to prevent accidental leakage of credentials, financial cards, national IDs,
        personal contact data, and confidential internal identifiers—while blocking
        adversarial prompt injection and data exfiltration attempts.
        """
    )

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Current Milestone", "Phase 2 Enhanced")
    with col2:
        st.metric("Sensitive Categories", str(len(DEFAULT_CATEGORY_RISK_MAP)))
    with col3:
        st.metric("RBAC Agent Profiles", str(len(AGENT_ROLES)))
    with col4:
        st.metric("Analysis Architecture", "Hybrid Local + Sanitized AI")

    st.divider()

    st.markdown("### Active Security Capabilities")
    capabilities = [
        {
            "Capability": "1. Expanded Sensitive-Data Detection",
            "Details": "12 categories including Email, Phone, API Keys, JWT, Private Keys, Luhn-validated Credit Cards, Aadhaar, PAN, IPv4, and Enterprise IDs",
            "Status": "✅ Active",
        },
        {
            "Capability": "2. Explainable Contextual Risk Scoring",
            "Details": "0–100 score with transparent factor breakdown and 2-bit Verilog hardware risk encoding (00..11)",
            "Status": "✅ Active",
        },
        {
            "Capability": "3. Prompt Injection & Exfiltration Detection",
            "Details": "Detects Instruction Override, System Prompt Extraction, Webhook/URL Exfiltration, Roleplay Jailbreaks, Encoding Bypasses + Hybrid AI analysis",
            "Status": "✅ Active",
        },
        {
            "Capability": "4. Policy Engine & Agent Authorization",
            "Details": "Role-based clearance enforcement (ALLOW / REDACT / BLOCK) with automatic span redaction",
            "Status": "✅ Active",
        },
        {
            "Capability": "5. Privacy-Conscious Audit Telemetry",
            "Details": "SHA-256 prompt hashing and metadata-only JSONL logging (never stores raw prompts or matched secrets)",
            "Status": "✅ Active",
        },
        {
            "Capability": "6. Automated Security Test Suite",
            "Details": "Comprehensive pytest suite verifying detection, Luhn checks, injection defense, RBAC policy, and zero-leakage logs",
            "Status": "✅ Active",
        },
    ]
    st.table(capabilities)

    st.info(
        "Open **Security Scanner** from the left sidebar to test prompts, switch Agent Roles, "
        "toggle Hybrid AI Analysis, and inspect the Privacy-Conscious Audit Log."
    )


if __name__ == "__main__":
    main()