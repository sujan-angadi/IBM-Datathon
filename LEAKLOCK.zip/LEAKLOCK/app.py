"""
LEAKLOCK — AI Data Protection Gateway
Main Streamlit Entrypoint (Home Page)
"""

from __future__ import annotations

import streamlit as st

from services import (
    get_audit_events,
    get_available_roles,
    get_supported_categories,
    load_sample_prompts,
)

st.set_page_config(
    page_title="LEAKLOCK | AI Data Protection Gateway",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)


def render_home() -> None:
    st.title("🛡️ LEAKLOCK — AI Data Protection Gateway")
    st.markdown(
        "**Inspect, score, redact, or block sensitive prompts locally before they ever reach an external AI service.**"
    )

    st.info(
        "**Prototype Security Notice:** LEAKLOCK is an application-layer security gateway prototype. "
        "While it enforces deterministic policy rules and fail-closed error handling, pattern and heuristic "
        "detection is not guaranteed to catch every novel prompt injection, obfuscation technique, or data exfiltration attempt."
    )

    st.divider()

    # Core Security Workflow
    st.subheader("End-to-End Gateway Workflow")
    wf_cols = st.columns(7)
    steps = [
        ("1. Prompt Intake", "Receive untrusted prompt & role context."),
        ("2. Secret Scan", "Detect credentials, PII, & tokens."),
        ("3. Threat Check", "Identify injection & jailbreak patterns."),
        ("4. Risk Scoring", "Compute explainable 0–100 score."),
        ("5. Policy Gate", "Evaluate role rules (fail-closed)."),
        ("6. Enforcement", "ALLOW, REDACT, or BLOCK output."),
        ("7. Audit Log", "Record metadata-only telemetry."),
    ]
    for col, (title, desc) in zip(wf_cols, steps):
        with col:
            with st.container(border=True):
                st.markdown(f"**{title}**")
                st.caption(desc)

    st.divider()

    # Real Engine & Session Telemetry
    st.subheader("Live Gateway Telemetry")
    events, is_in_memory = get_audit_events()
    roles = get_available_roles()
    categories = get_supported_categories()

    cfg_col1, cfg_col2, cfg_col3, cfg_col4 = st.columns(4)
    cfg_col1.metric("Configured Agent Roles", len(roles))
    cfg_col2.metric("Supported Detection Categories", len(categories) if categories else "Engine Default")
    cfg_col3.metric("Total Prompts Analyzed", len(events))

    if events:
        blocked_count = sum(1 for e in events if e.get("decision") == "BLOCK")
        redacted_count = sum(1 for e in events if e.get("decision") == "REDACT")
        allowed_count = sum(1 for e in events if e.get("decision") == "ALLOW")
        avg_risk = round(sum(e.get("risk_score", 0) for e in events) / len(events), 1)
        cfg_col4.metric("Average Risk Score", f"{avg_risk} / 100")

        m1, m2, m3 = st.columns(3)
        m1.metric("Allowed Requests (ALLOW)", allowed_count)
        m2.metric("Sanitized Requests (REDACT)", redacted_count)
        m3.metric("Blocked Requests (BLOCK)", blocked_count)
    else:
        cfg_col4.metric("Average Risk Score", "N/A")
        st.caption(
            "No prompts have been analyzed in the current audit log yet. "
            "Open the **Security Scanner** to inspect a prompt and generate live telemetry."
        )

    if is_in_memory:
        st.caption("ℹ️ Audit telemetry is currently held in memory and will reset when the application restarts.")

    st.divider()

    # Navigation Cards
    st.subheader("Gateway Modules")
    nav1, nav2, nav3, nav4 = st.columns(4)

    with nav1:
        with st.container(border=True):
            st.markdown("### 🔍 Security Scanner")
            st.write("Inspect prompts interactively across agent roles, view risk breakdowns, and preview sanitized outputs.")
            if hasattr(st, "page_link"):
                st.page_link("pages/1_Security_Scanner.py", label="Open Security Scanner", icon="🔍")

    with nav2:
        with st.container(border=True):
            st.markdown("### 📜 Policy Manager")
            st.write("Review role-based redaction and blocking policies, threat handling rules, and fail-closed guarantees.")
            if hasattr(st, "page_link"):
                st.page_link("pages/2_Policy_Manager.py", label="Open Policy Manager", icon="📜")

    with nav3:
        with st.container(border=True):
            st.markdown("### 📊 Audit Dashboard")
            st.write("Explore metadata-only security events, filter by role or decision, and export JSONL audit logs.")
            if hasattr(st, "page_link"):
                st.page_link("pages/3_Audit_Dashboard.py", label="Open Audit Dashboard", icon="📊")

    with nav4:
        with st.container(border=True):
            st.markdown("### ℹ️ About LEAKLOCK")
            st.write("Read the architecture overview, privacy model, supported categories, and platform instructions.")
            if hasattr(st, "page_link"):
                st.page_link("pages/4_About.py", label="Open About Page", icon="ℹ️")


def main() -> None:
    render_home()


if __name__ == "__main__":
    render_home()