# LEAKLOCK Architecture Specification

## 1. High-Level System Overview

LEAKLOCK is a modular AI Data Protection Gateway built for the **IBM Z Datathon 2026** ('AI Secured: Innovation Without Exposure').

```text
Streamlit UI (app.py, pages/)
       │
       ▼
core/detector.py          ← Regex engine: 12 sensitive-data categories
core/threat_detector.py   ← Prompt injection / exfiltration rule engine
core/risk_scorer.py       ← Explainable 0–100 contextual risk scoring
core/policy_engine.py     ← RBAC ALLOW / REDACT / BLOCK enforcement
core/audit_logger.py      ← SHA-256 fingerprint + metadata-only logging
       │
       ▼
services/                 ← Phase 3+ Decision & Bridge services
       │
       ▼
hardware/interface/       ← Future: Python ↔ Verilog/FPGA bridge
```

## 2. Phase 2 Boundary Guarantees

- **Zero Prompt Storage:** Prompts are processed strictly in memory and are never written to disk.
- **Zero Secret Leakage in Logs:** Audit records store SHA-256 fingerprints, category counts, risk scores, and policy decisions — never raw prompt text or matched secrets.
- **Pre-Redacted AI Analysis:** When Hybrid AI analysis is enabled, all sensitive spans are replaced with `[REDACTED_<CATEGORY>]` before the text reaches the AI analysis layer.
- **Fail-Closed Policy:** Categories not explicitly in a role's redactable or blocked set default to BLOCK.
- **Hardware Independence:** Runs cleanly on Windows 11, Rocky Linux 10.x, and IBM LinuxONE using only Python 3.10+ and Streamlit.

## 3. Data Flow

```text
User Prompt (untrusted input)
       │
       ▼
detect_sensitive_data()
   ├── Run _RULES regex patterns → raw_candidates
   ├── Secondary validation (Luhn, IPv4 octets, phone digit count)
   ├── _resolve_overlaps() → findings (non-overlapping, sorted by offset)
   ├── _mask_spans_for_ai() → sanitized text (for optional AI layer)
   ├── detect_prompt_threats() → threat_report
   └── calculate_contextual_risk() → risk_eval
       │
       ▼
evaluate_policy(prompt, scan_result, agent_role)
   ├── Check for threats → BLOCK
   ├── Check findings against blocked_categories → BLOCK
   ├── Check findings against redactable_categories → REDACT
   └── No violations → ALLOW
       │
       ▼
audit_logger.log_scan_event()
   ├── SHA-256(prompt) → prompt_sha256
   ├── Category counts (no matched_text)
   ├── Risk score and level
   └── Policy action and role
```

## 4. Detection Priority System

Rules are sorted by priority (higher = evaluated first for overlap resolution):

| Priority | Category |
|---|---|
| 110 | `PRIVATE_KEY_HEADER` |
| 105 | `JWT_TOKEN` |
| 100 | `API_KEY` (assignment form) |
| 95 | `API_KEY` (prefixed form: sk-, gh-, AKIA) |
| 92 | `CREDIT_CARD` (Luhn validated) |
| 91 | `PAN_ID` |
| 90 | `EMPLOYEE_ID`, `CUSTOMER_ID` |
| 88 | `AADHAAR_ID` |
| 85 | `CONFIDENTIAL_IDENTIFIER` |
| 80 | `EMAIL` |
| 75 | `IPV4_ADDRESS` |
| 70 | `PHONE` (Indian) |
| 65 | `PHONE` (International) |
