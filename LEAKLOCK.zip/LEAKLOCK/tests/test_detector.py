"""
Automated pytest suite for LEAKLOCK Phase 2: Sensitive Data Detection Engine.
Uses strictly synthetic data to verify detection accuracy, offsets, risk levels,
overlap resolution, and edge-case handling.
"""

from __future__ import annotations

import pytest

from core.detector import detect_sensitive_data


def test_detect_email_address() -> None:
    prompt = "Contact me at sujan@example.com for project updates."
    result = detect_sensitive_data(prompt)

    assert result["has_sensitive_data"] is True
    assert result["risk_level"] == "MEDIUM"
    assert len(result["findings"]) == 1

    finding = result["findings"][0]
    assert finding["category"] == "EMAIL"
    assert finding["risk_level"] == "MEDIUM"
    assert finding["matched_text"] == "sujan@example.com"
    assert prompt[finding["start"] : finding["end"]] == "sujan@example.com"
    assert result["category_counts"] == {"EMAIL": 1}


@pytest.mark.parametrize(
    "phone_sample",
    [
        "+91 98765 43210",
        "+91-9876543210",
        "9876543210",
        "+1-415-555-0199",
        "(415) 555-0199",
    ],
)
def test_detect_supported_phone_formats(phone_sample: str) -> None:
    prompt = f"Reach the on-call engineer at {phone_sample} immediately."
    result = detect_sensitive_data(prompt)

    assert result["has_sensitive_data"] is True
    assert result["risk_level"] == "MEDIUM"
    assert len(result["findings"]) == 1

    finding = result["findings"][0]
    assert finding["category"] == "PHONE"
    assert finding["matched_text"] == phone_sample
    assert prompt[finding["start"] : finding["end"]] == phone_sample


def test_arbitrary_digit_sequences_not_flagged_as_phone() -> None:
    # Starts with 1-5 without country/area formatting or has fewer/more digits
    prompt = "Invoice 1234567890 and build ID 44556677 were deployed at 20261017."
    result = detect_sensitive_data(prompt)

    assert result["has_sensitive_data"] is False
    assert result["findings"] == []
    assert result["risk_level"] == "LOW"


@pytest.mark.parametrize(
    "credential_snippet",
    [
        "sk-demo-123456789abcdef",
        "api_key=DEMO_SECRET_123456",
        "token: DEMO_TOKEN_ABC123",
    ],
)
def test_detect_api_key_like_strings(credential_snippet: str) -> None:
    prompt = f"Debug config with {credential_snippet} in local test."
    result = detect_sensitive_data(prompt)

    assert result["has_sensitive_data"] is True
    assert result["risk_level"] == "HIGH"
    assert len(result["findings"]) == 1

    finding = result["findings"][0]
    assert finding["category"] == "API_KEY"
    assert finding["risk_level"] == "HIGH"
    assert finding["matched_text"] == credential_snippet
    assert prompt[finding["start"] : finding["end"]] == credential_snippet


def test_detect_employee_customer_and_confidential_identifiers() -> None:
    prompt = (
        "Assign EMP-12345 to review ticket for CUST-98765 "
        "under PROJECT-ALPHA-CONFIDENTIAL."
    )
    result = detect_sensitive_data(prompt)

    assert result["has_sensitive_data"] is True
    assert result["risk_level"] == "HIGH"
    assert len(result["findings"]) == 3

    categories = [f["category"] for f in result["findings"]]
    assert categories == ["EMPLOYEE_ID", "CUSTOMER_ID", "CONFIDENTIAL_IDENTIFIER"]

    matched_texts = [f["matched_text"] for f in result["findings"]]
    assert matched_texts == [
        "EMP-12345",
        "CUST-98765",
        "PROJECT-ALPHA-CONFIDENTIAL",
    ]

    for finding in result["findings"]:
        assert prompt[finding["start"] : finding["end"]] == finding["matched_text"]


def test_multiple_categories_and_risk_escalation() -> None:
    prompt = (
        "Email sujan@example.com or call +91 98765 43210 "
        "to rotate sk-demo-123456789abcdef for EMP-12345."
    )
    result = detect_sensitive_data(prompt)

    assert result["has_sensitive_data"] is True
    # MEDIUM (email, phone) + HIGH (api_key, employee_id) -> overall HIGH
    assert result["risk_level"] == "HIGH"
    assert len(result["findings"]) == 4
    assert result["category_counts"] == {
        "EMAIL": 1,
        "PHONE": 1,
        "API_KEY": 1,
        "EMPLOYEE_ID": 1,
    }


def test_multiple_occurrences_of_same_category() -> None:
    prompt = "Copy alice@example.com, bob@example.org, and charlie@example.net."
    result = detect_sensitive_data(prompt)

    assert result["has_sensitive_data"] is True
    assert result["risk_level"] == "MEDIUM"
    assert len(result["findings"]) == 3
    assert result["category_counts"] == {"EMAIL": 3}
    assert [f["matched_text"] for f in result["findings"]] == [
        "alice@example.com",
        "bob@example.org",
        "charlie@example.net",
    ]


def test_prompt_with_no_sensitive_patterns() -> None:
    prompt = "Write a Python function to compute Fibonacci numbers iteratively."
    result = detect_sensitive_data(prompt)

    assert result["has_sensitive_data"] is False
    assert result["risk_level"] == "LOW"
    assert result["findings"] == []
    assert result["category_counts"] == {}
    assert "No supported sensitive-data patterns" in result["summary"]


@pytest.mark.parametrize("empty_value", ["", "   ", "\n\t  "])
def test_empty_or_whitespace_input(empty_value: str) -> None:
    result = detect_sensitive_data(empty_value)

    assert result["has_sensitive_data"] is False
    assert result["risk_level"] == "LOW"
    assert result["findings"] == []
    assert result["category_counts"] == {}


@pytest.mark.parametrize("invalid_input", [None, 12345, ["prompt"], {"text": "hi"}])
def test_invalid_input_types_raise_type_error(invalid_input: object) -> None:
    with pytest.raises(TypeError):
        detect_sensitive_data(invalid_input)  # type: ignore[arg-type]


def test_overlapping_patterns_do_not_duplicate() -> None:
    # `token: sk-demo-123456789abcdef` matches both `api_key_assignment` (whole span)
    # and `api_key_prefixed` (inner `sk-demo-...` span). Only the outer span should remain.
    prompt = "Header uses token: sk-demo-123456789abcdef for auth."
    result = detect_sensitive_data(prompt)

    assert len(result["findings"]) == 1
    finding = result["findings"][0]
    assert finding["category"] == "API_KEY"
    assert finding["matched_text"] == "token: sk-demo-123456789abcdef"
    assert prompt[finding["start"] : finding["end"]] == "token: sk-demo-123456789abcdef"


def test_adjacent_matches_and_deterministic_ordering() -> None:
    prompt = "EMP-12345,CUST-98765,sujan@example.com"
    first_run = detect_sensitive_data(prompt)
    second_run = detect_sensitive_data(prompt)

    assert first_run == second_run
    starts = [f["start"] for f in first_run["findings"]]
    assert starts == sorted(starts)
    assert [f["matched_text"] for f in first_run["findings"]] == [
        "EMP-12345",
        "CUST-98765",
        "sujan@example.com",
    ]


def test_configurable_risk_override_for_future_policy_phases() -> None:
    prompt = "Project lead email: lead@example.com under PROJECT-ALPHA-CONFIDENTIAL"
    custom_map = {
        "EMAIL": "LOW",
        "CONFIDENTIAL_IDENTIFIER": "CRITICAL",
    }
    result = detect_sensitive_data(prompt, risk_map=custom_map)

    assert result["risk_level"] == "CRITICAL"
    assert result["findings"][0]["risk_level"] == "LOW"
    assert result["findings"][1]["risk_level"] == "CRITICAL"


def test_invalid_risk_map_raises_value_error() -> None:
    with pytest.raises(ValueError):
        detect_sensitive_data("sujan@example.com", risk_map={"EMAIL": "EXTREME"}) 